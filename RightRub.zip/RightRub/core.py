def hello():
    return "🔥 Welcome to RightRub Library!"

def rtl(text):
    return text[::-1]