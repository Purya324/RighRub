# RightRub

Simple Python RTL utility library.

## Install

pip install RightRub

## Usage

```python
from RightRub import hello, rtl

print(hello())
print(rtl("سلام"))